import ConfirmedBooking from '../components/ConfirmedBooking/ConfirmedBooking';

const ConfirmedBookingPage = () => {
  return (
    <>
      <ConfirmedBooking />
    </>
  );
};

export default ConfirmedBookingPage;
